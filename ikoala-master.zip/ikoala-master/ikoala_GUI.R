
list.of.packages <- c("xtable","pander","knitr","rgdal","plyr", "psych","ggmap","RgoogleMaps","ggplot2","vegan","akima","reshape2","RColorBrewer","rmarkdown", "tcltk","tcltk2")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

 suppressMessages(library(xtable, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(pander, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(knitr, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(rgdal, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(plyr, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(psych, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(ggmap, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(RgoogleMaps, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(ggplot2, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(vegan, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(akima, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(reshape2, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(RColorBrewer, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(rmarkdown, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(tcltk, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(tcltk2, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(rmarkdown, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(RColorBrewer, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(sp, quietly=TRUE, warn.conflicts=FALSE))
 suppressMessages(library(maptools, quietly=TRUE, warn.conflicts=FALSE))

 #### check for pandoc. If not available search on stick!!! otherwise use existing one.
 if (!pandoc_available())  Sys.setenv(PATH = paste(paste0(toupper(substr(getwd(),1,2)),"/R-Portable/pandoc"),Sys.getenv("PATH"),  sep=.Platform$path.sep))
 
 
 
 koalaGUI <- function(){
  
  xvar <- tclVar("declocations.csv")
  yvar <- tclVar("dectreenames.csv")
  zvar <- tclVar("dectrees.csv")
  cbval350 <- tclVar("0")
  cbval500 <- tclVar("0")
  cbval1000 <- tclVar("0")
  resfolder <- tclVar("results")
  studysite <- tclVar("Southern Tablelands")
  repname <- tclVar("ikoala.docx")

  
  tt <- tktoplevel()
  img <- tclVar()
  ik <-tkimage.create("photo", img, file="ikoala.gif")
 icon <- tk2ico.create("ikoala.ico")
 tk2ico.set(tt, icon)
 cb350 <- tkcheckbutton(tt, variable = cbval350, text="Grid 350")  
 cb500 <- tkcheckbutton(tt, variable = cbval500, text="Grid 500")  
 cb1000 <- tkcheckbutton(tt, variable = cbval1000, text="Grid 1000")    
  
  sf <- tclVar(paste0(toupper(substr(getwd(),1,2)),"/ikoala"))
  files <-tclVar(as.character(paste(dir(path=tclvalue(sf),pattern=".csv"), collapse=", ")))
  label1 <- tklabel(tt, text=tclvalue(sf))
  label2<- tklabel(tt, text=tclvalue(files))
  tkconfigure(label1, textvariable=sf)
  tkconfigure(label2, textvariable=files)
  tkwm.title(tt,"ikoala")
  x.entry <- tkentry(tt, textvariable=xvar)
  y.entry <- tkentry(tt, textvariable=yvar)
  z.entry <- tkentry(tt, textvariable=zvar)
  sf.entry <- tkentry(tt, textvariable=sf)
  files.entry <- tkentry(tt, textvariable = files)
  res.entry <- tkentry(tt, textvariable=resfolder)
  study.entry <- tkentry(tt, textvariable=studysite)
  out.entry <- tkentry(tt, textvariable=repname)
  reset <- function() {
    tclvalue(xvar)<-""
    tclvalue(yvar)<-""
    tclvalue(zvar)<-""
    tclvalue(sf) <-""
    tclvalue(files)<- ""
    tclvalue(resfolder) <- "results"
    tclvalue(studysite) <- "Southern Tablelands"
    tclvalue(repname) <- "ikoala.docx"
    tclvalue(cb350) <- "0"
    tclvalue(cb500) <- "0"
    tclvalue(cb1000) <- "0"
    
    }
  
  
  selfolder.but <- tkbutton(tt, text="Select folder", command=function() {
    tclvalue(sf)=tk_choose.dir() 
    tclvalue(files) = paste(dir(path=tclvalue(sf), pattern=".csv"), collapse=", ")
  })
  reset.but <- tkbutton(tt, text="Reset", command=reset)
  
  submit <- function() {
   olddir <- getwd()
   setwd(tclvalue(sf))
    render("ikoala.rmd", output_file = tclvalue(repname),word_document(fig_caption = TRUE, toc = TRUE, reference_docx = "ikoala-template.docx"), params = list(resultsfolder=tclvalue(resfolder), studysite=tclvalue(studysite), workdir = tclvalue(sf), location_table= tclvalue(xvar), tree_table= tclvalue(zvar), tree_list_table= tclvalue(yvar), repname=tclvalue(repname), grid350=tclvalue(cbval350), grid500=tclvalue(cbval500), grid1000=tclvalue(cbval1000)), clean = TRUE)
   setwd(olddir)
    
   tkmessageBox(type="ok",message=paste("Report has been created. \nCheck file:",tclvalue(repname)," in the folder:",tclvalue(sf),"for the report." ))
    
#    
#     cat(paste("cb350value",tclvalue(cbval350)))
#     cat(paste("cb500value",tclvalue(cbval500)))
#     cat(paste("cb1000value",tclvalue(cbval1000)))
#     
    
  }
  submit.but <- tkbutton(tt, text="Click to create an ikoala report", image=ik, compound="top", command=submit)

  tkgrid(tklabel(tt,text="1. Select folder with database csv files"), columnspan=1, pady=10, padx=10)
  tkgrid(selfolder.but, label1, columnspan =1, pady=10, padx=10)
  tkgrid(tklabel(tt,text="available csv files: "),label2, columnspan =1, pady=10, padx=10)
  tkgrid(tklabel(tt,text="2. Specify tables (csv file names)        "),  pady=10, padx=10)
  tkgrid(tklabel(tt,text="Location table"), x.entry, pady= 10, padx= 10)
  tkgrid(tklabel(tt,text="Treelist"), y.entry, pady= 10, padx= 10)
  tkgrid(tklabel(tt,text="Tree details"), z.entry, pady= 10, padx= 10)
  tkgrid(tklabel(tt,text="3. Specify a results folder name           "),  pady=10, padx=10)
  tkgrid(tklabel(tt,text="results folder "),res.entry, pady= 10, padx= 10)
  tkgrid(tklabel(tt,text="4. Specify study sites filter              "),  pady=10, padx=10)
  tkgrid(tklabel(tt,text="Study site "),study.entry, pady= 10, padx= 10)
  tkgrid(tklabel(tt,text="5. Specify Grid filter                     "),  pady=10, padx=10)
  tkgrid(cb350, cb500, cb1000,  pady=10, padx=10)
  tkgrid(tklabel(tt,text="6. Specify report name                      "),  pady=10, padx=10)
  tkgrid(tklabel(tt,text="report name "),out.entry, pady= 10, padx= 10)
  tkgrid(submit.but, reset.but,  pady= 10, padx= 10)
  cat("We hope you enjoy using iKoala!\n")
  tkwait.window(tt)
}

koalaGUI ()
